# =============================================================================
# main.py — Entry point for the Drowsiness Detection System
#
# Usage:
#   python main.py              → live detection (requires trained model)
#   python main.py --check      → pre-flight environment check only
# =============================================================================

import sys
import os
import argparse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from config import MODEL_PATH, DATASET_PATH


def parse_args():
    parser = argparse.ArgumentParser(description="Driver Drowsiness Detection")
    parser.add_argument("--check", action="store_true",
                        help="Run environment check and exit.")
    return parser.parse_args()


def preflight_check() -> bool:
    """
    Verify all dependencies and project artefacts are in place.
    Returns True if everything is ready to run.
    """
    print("\n── Pre-flight Check ─────────────────────────────────")
    all_ok = True

    # 1. Python packages
    packages = {
        "cv2":       "opencv-python",
        "mediapipe": "mediapipe",
        "numpy":     "numpy",
        "pandas":    "pandas",
        "sklearn":   "scikit-learn",
        "joblib":    "joblib",
        "scipy":     "scipy",
    }
    for module, pkg in packages.items():
        try:
            __import__(module)
            print(f"  [OK]  {pkg}")
        except ImportError:
            print(f"  [FAIL] {pkg} — run: pip install {pkg}")
            all_ok = False

    # 2. Dataset
    if os.path.exists(DATASET_PATH):
        import pandas as pd
        df = pd.read_csv(DATASET_PATH)
        print(f"  [OK]  Dataset found ({len(df)} rows) → {DATASET_PATH}")
    else:
        print(f"  [WARN] No dataset yet — run data_collector.py first")

    # 3. Trained model
    if os.path.exists(MODEL_PATH):
        print(f"  [OK]  Model found → {MODEL_PATH}")
    else:
        print(f"  [WARN] No trained model yet — run: python -m src.model.trainer")

    print("─────────────────────────────────────────────────────\n")
    return all_ok


def run_live_detection():
    """
    Full live-detection pipeline.
    Will be wired up in Milestone 9 (live prediction integration).
    """
    # Import here so missing packages only fail when this path is taken
    import cv2
    from src.vision.camera import Camera
    from src.vision.landmark_detector import LandmarkDetector
    from src.features.extractor import FeatureExtractor
    from src.model.predictor import DrowsinessPredictor

    predictor = DrowsinessPredictor()
    predictor.load()
    extractor = FeatureExtractor()

    print("[INFO] Starting live detection. Press 'q' to quit.")

    with Camera() as cam, LandmarkDetector() as detector:
        while True:
            ret, frame = cam.read()
            if not ret:
                continue

            result = detector.process(frame)
            annotated = detector.draw_landmarks(frame, result)

            if result.face_detected:
                fv = extractor.extract(result)
                label_int, confidence = predictor.predict(fv.to_model_input())

                label_text = f"{'DROWSY' if label_int else 'AWAKE'} ({confidence:.0%})"
                color = (0, 0, 255) if label_int else (0, 255, 0)
                cv2.putText(annotated, label_text, (10, 30),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.9, color, 2)
            else:
                cv2.putText(annotated, "No face", (10, 30),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 165, 255), 2)

            cv2.imshow("Drowsiness Detection — q to quit", annotated)
            if cv2.waitKey(1) & 0xFF == ord("q"):
                break


def main():
    print("=" * 52)
    print("  Driver Drowsiness Detection System")
    print("=" * 52)

    args = parse_args()

    if args.check:
        preflight_check()
        return

    ok = preflight_check()
    if not ok:
        print("[ERROR] Fix missing dependencies before running.")
        sys.exit(1)

    run_live_detection()


if __name__ == "__main__":
    main()
